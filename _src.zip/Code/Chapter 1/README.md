chapter1
==================

Code for the first chapter of the book, which is about discovering the Arduino Ethernet shield.

- client_example: the sketch to test the Ethernet shield by connecting to a remote server and grabbing a test page