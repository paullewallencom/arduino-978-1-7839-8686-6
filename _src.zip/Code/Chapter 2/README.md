chapter2
==================

Code for the second chapter of the book, which is about sending measurements to a local web server

- dht_client: the sketch to make temperature and humidity measurements, and the data to a local web server
- plot: the server-side code to log the data in a database, and to display it on a web page