chapter3
==================

Code for the third chapter of the book, which is about creating a datalogging server on the Arduino Ethernet shield

- sd_datalogger: the Arduino sketch to make log data on a SD card
- measurement_server: the Arduino sketch to create a web server on the Arduino board
- measurement_json: the Arduino sketch to create a web server on the Arduino board and return results in JSON
- plot: the server-side files to plot the data recorded by the Arduino board