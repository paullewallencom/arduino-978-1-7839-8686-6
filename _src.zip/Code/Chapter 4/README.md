chapter4
==================

Code for the fourth chapter of the book, which is about controlling a relay remotely using the Arduino Ethernet shield

- sketches: the different sketches of this chapter
- interface_remote: the interface to control the relay from within your local network
- interface_anywhere: the interface to control the relay from anywhere in the world using Teleduino