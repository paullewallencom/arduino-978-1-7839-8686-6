chapter5
==================

Code for the fifth chapter of the book, dedicated an Internet of Things project with Xively

- dht_xively: the Arduino sketch of the chapter that measures data & send it to Xively