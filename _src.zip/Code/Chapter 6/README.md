chapter6
==================

Code for the sixth chapter of the book, dedicated using the web services from Temboo to log data in a Google Docs spreadsheet & send automated email alerts

- log_spreadsheet: the Arduino sketch of the chapter that measures data & log this data in a Google Docs spreadsheet
- send_email: the Arduino sketch of the chapter that measures data & send automated email alerts based on the measured data